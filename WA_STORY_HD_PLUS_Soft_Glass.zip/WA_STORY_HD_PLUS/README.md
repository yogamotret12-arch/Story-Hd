# WA STORY HD+ — Soft Glass Edition

Project Android native Kotlin dengan antarmuka minimalis soft-glass: latar biru pucat, kartu semi-transparan, sudut membulat, dan aksen biru lembut.

## Fitur versi awal
- Pilih foto dan ekspor salinan JPEG 1080×1920 kualitas 95%.
- Pilih video dan ekspor ulang MP4 H.264/AAC dengan tinggi 1920 px memakai Media3 Transformer.
- Hasil disimpan ke Pictures/WA Story HD+ dan Movies/WA Story HD+.
- File sumber tidak sengaja ditimpa.

## Build APK
1. Buka folder ini di Android Studio.
2. Gunakan JDK 17.
3. Sinkronkan Gradle.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Batasan versi awal
Ini source project, bukan APK yang sudah dikompilasi atau diuji di perangkat. Foto saat ini di-crop tengah menjadi 9:16; cek hasilnya sebelum unggah. Video dipertahankan rasio sumber dengan tinggi output 1920 px. WhatsApp tetap dapat mengompresi media saat Story diunggah. Upscaling tidak dapat menciptakan detail yang tidak ada di file asli.
