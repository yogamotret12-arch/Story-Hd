package com.wastoryhdplus

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private var transformer: Transformer? = null

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) {
        it?.let(::optimizePhoto)
    }
    private val videoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) {
        it?.let(::optimizeVideo)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(239, 245, 251)
        window.navigationBarColor = android.graphics.Color.rgb(239, 245, 251)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildInterface()
    }

    private fun buildInterface() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFFF5F9FD.toInt(), 0xFFEAF2FA.toInt(), 0xFFF8FAFD.toInt())
            )
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "W"
            textSize = 23f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFFFFFF.toInt())
            background = rounded(0xFF6CA9D8.toInt(), 18)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        brand.addView(label("WA STORY HD+", 19f, 0xFF23364A.toInt(), true))
        brand.addView(label("PHOTO  ·  VIDEO ENHANCER", 9f, 0xFF7890A7.toInt(), true))
        top.addView(logo)
        top.addView(brand)
        val version = TextView(this).apply {
            text = "v1.0"
            textSize = 11f
            setTextColor(0xFF6E879F.toInt())
            gravity = Gravity.CENTER
            background = rounded(0xFFE4EDF5.toInt(), 30)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        }
        top.addView(version, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_VERTICAL; weight = 1f; marginStart = dp(8) })
        page.addView(top)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            background = rounded(0xFFE4F0FA.toInt(), 24, 0xFFD6E5F1.toInt())
        }
        hero.addView(label("Story lebih jernih,", 25f, 0xFF20384F.toInt(), true))
        hero.addView(label("tanpa ribet.", 25f, 0xFF548AB8.toInt(), true))
        hero.addView(label("Optimalkan media sebelum dibagikan ke WhatsApp.", 13f, 0xFF607A91.toInt(), false).apply {
            setPadding(0, dp(8), 0, dp(16))
        })
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chipRow.addView(chip("PHOTO HD"))
        chipRow.addView(spaceH(8))
        chipRow.addView(chip("VIDEO HD"))
        hero.addView(chipRow)
        page.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        page.addView(label("PILIH MEDIA", 11f, 0xFF71869B.toInt(), true).apply {
            setPadding(dp(2), dp(25), 0, dp(10))
        })

        val photoCard = mediaCard("01", "Optimalkan foto", "JPEG kualitas tinggi  ·  Kanvas Story 9:16", "PILIH FOTO") {
            photoPicker.launch("image/*")
        }
        page.addView(photoCard)
        page.addView(spaceV(12))
        val videoCard = mediaCard("02", "Optimalkan video", "MP4 H.264  ·  Tinggi hingga 1920 px", "PILIH VIDEO") {
            videoPicker.launch("video/*")
        }
        page.addView(videoCard)

        val quality = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17))
            background = rounded(0xDFFFFFFF.toInt(), 20, 0xFFDDE7F0.toInt())
        }
        quality.addView(label("PENGATURAN KUALITAS", 11f, 0xFF607A91.toInt(), true))
        quality.addView(label("Foto  ·  1080 × 1920 px  ·  JPEG 95%", 13f, 0xFF314B63.toInt(), true).apply { setPadding(0, dp(12), 0, dp(5)) })
        quality.addView(label("Video  ·  H.264 / AAC  ·  tinggi 1920 px", 13f, 0xFF314B63.toInt(), false))
        page.addView(quality, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        progress = ProgressBar(this).apply { visibility = View.GONE; indeterminateTintList = android.content.res.ColorStateList.valueOf(0xFF5D9BCB.toInt()) }
        page.addView(progress, LinearLayout.LayoutParams(-2, dp(32)).apply { gravity = Gravity.CENTER; topMargin = dp(12) })
        status = label("Pilih foto atau video untuk mulai.", 12f, 0xFF5D7C98.toInt(), false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(10), dp(4), dp(4))
        }
        page.addView(status)

        page.addView(label("Hasil disimpan sebagai file baru. File asli tetap aman. WhatsApp masih dapat melakukan kompresi saat Story diunggah.", 10f, 0xFF8799AA.toInt(), false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(18), dp(8), 0)
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(0xFFF5F9FD.toInt())
            addView(page)
        })
    }

    private fun mediaCard(number: String, title: String, desc: String, button: String, action: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17))
            background = rounded(0xEFFFFFFF.toInt(), 22, 0xFFDCE7F0.toInt())
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val bubble = TextView(this).apply {
            text = number
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFF548AB8.toInt())
            background = rounded(0xFFE7F1F9.toInt(), 14)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        texts.addView(label(title, 16f, 0xFF263D53.toInt(), true))
        texts.addView(label(desc, 11f, 0xFF8295A7.toInt(), false).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(bubble)
        row.addView(texts)
        card.addView(row)
        val btn = TextView(this).apply {
            text = "$button   →"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = rounded(0xFF6C9FC8.toInt(), 14)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setOnClickListener { action() }
        }
        card.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(15) })
        return card
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun chip(text: String) = TextView(this).apply {
        this.text = text
        textSize = 9f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF477AA5.toInt())
        background = rounded(0xFFF6FBFF.toInt(), 30)
        setPadding(dp(11), dp(7), dp(11), dp(7))
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun spaceV(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun spaceH(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(width), 1) }

    private fun optimizePhoto(uri: Uri) {
        try {
            setBusy(true, "Sedang mengoptimalkan foto…")
            val source = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                ?: throw IllegalStateException("Foto tidak dapat dibaca.")
            val targetW = 1080
            val targetH = 1920
            val scale = maxOf(targetW.toFloat() / source.width, targetH.toFloat() / source.height)
            val scaledW = (source.width * scale).toInt()
            val scaledH = (source.height * scale).toInt()
            val scaled = Bitmap.createScaledBitmap(source, scaledW, scaledH, true)
            val x = ((scaledW - targetW) / 2).coerceAtLeast(0)
            val y = ((scaledH - targetH) / 2).coerceAtLeast(0)
            val output = Bitmap.createBitmap(scaled, x, y, targetW, targetH)

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "WA_STORY_HD_${stamp()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/WA Story HD+")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resultUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file hasil.")
            contentResolver.openOutputStream(resultUri)?.use { output.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                ?: throw IllegalStateException("Tidak bisa menyimpan foto.")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(resultUri, values, null, null)

            source.recycle()
            if (scaled !== source) scaled.recycle()
            output.recycle()
            setBusy(false, "Selesai! Foto tersimpan di Pictures/WA Story HD+")
        } catch (e: Exception) {
            setBusy(false, "Gagal memproses foto: ${e.message}")
        }
    }

    private fun optimizeVideo(uri: Uri) {
        try {
            setBusy(true, "Video sedang diekspor. Mohon tunggu…")
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "WA_STORY_HD_${stamp()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/WA Story HD+")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file video.")
            val descriptor = contentResolver.openFileDescriptor(outputUri, "rw")
                ?: throw IllegalStateException("Tidak bisa membuka file tujuan.")
            val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
                .setEffects(Effects(emptyList(), listOf(Presentation.createForHeight(1920))))
                .build()

            transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        descriptor.close()
                        values.clear()
                        values.put(MediaStore.Video.Media.IS_PENDING, 0)
                        contentResolver.update(outputUri, values, null, null)
                        transformer = null
                        setBusy(false, "Selesai! Video tersimpan di Movies/WA Story HD+")
                    }
                    override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                        descriptor.close()
                        contentResolver.delete(outputUri, null, null)
                        transformer = null
                        setBusy(false, "Gagal memproses video: ${exportException.message}")
                    }
                }).build()
            transformer?.start(edited, descriptor.fileDescriptor)
        } catch (e: Exception) {
            transformer = null
            setBusy(false, "Gagal memproses video: ${e.message}")
        }
    }

    private fun setBusy(busy: Boolean, message: String) = runOnUiThread {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        status.text = message
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
